#!/usr/bin/env python3
"""Bridge de TikTok → wordch4t.

Lee el chat de un live de TikTok y envía cada mensaje al servidor del juego
(POST /api/game/answer). Los regalos (gifts) revelan sílabas en el modo
palabra (POST /api/game/gift).

Uso real:
    py -3.12 tiktok_bridge.py --session <session_id> --user @tucuenta

Modo mock (sin TikTok, para demos y pruebas):
    py -3.12 tiktok_bridge.py --session <session_id> --mock

Opcional:
    --server http://localhost:8787     (default)
    --gifts                            (reenvía regalos → revelar sílaba)
    --seconds 30                       (duración en modo mock)
"""

import argparse
import asyncio
import json
import random
import time
import urllib.request

VIEWERS = ["ana", "beto", "carla", "dora", "elena", "frank", "gaby", "hugo"]
PALABRAS_FALSAS = ["perro", "gato", "casa", "piano", "fiesta", "teclado", "camino", "estrella", "botella", "ventana"]
LETRAS = ["a", "b", "c", "d"]


def enviar(server: str, path: str, payload: dict):
    try:
        req = urllib.request.Request(
            server + path,
            data=json.dumps(payload).encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read() or b"{}")
    except Exception as e:  # best-effort: el bridge nunca debe caerse
        return 0, {"error": str(e)}


def enviar_respuesta(server: str, sid: str, player: str, text: str):
    st, body = enviar(server, "/api/game/answer", {"session_id": sid, "player": player, "text": text})
    marca = "✔" if body.get("correct") else "·"
    print(f"[respuesta] {player}: {text!r} -> {st} {marca} {body.get('points', '')}")


def enviar_gift(server: str, sid: str, player: str, count: int = 1):
    st, body = enviar(server, "/api/game/gift", {"session_id": sid, "player": player, "count": count})
    print(f"[gift] {player} x{count} -> {st} {body}")


def ping_live(server: str, sid: str, etiqueta: str = "live"):
    """Avisa al juego que el live está conectado (la partida lo espera para arrancar)."""
    st, _ = enviar(server, "/api/game/bridge", {"session_id": sid})
    if st == 200:
        print(f"[{etiqueta}] Live conectado al juego ✔ (session {sid})")
    else:
        print(f"[{etiqueta}] aviso: no pude avisar al juego (status {st})")
    return st == 200


async def modo_mock(args):
    print(f"Modo MOCK: simulando chat durante {args.seconds}s (session {args.session})")
    ping_live(args.server, args.session, "mock")
    t0 = time.time()
    last_ping = time.time()
    n = 0
    while time.time() - t0 < args.seconds:
        if time.time() - last_ping > 10:
            ping_live(args.server, args.session, "mock")
            last_ping = time.time()
        viewer = random.choice(VIEWERS)
        if args.gifts and n % 5 == 4:
            enviar_gift(args.server, args.session, viewer, random.choice([1, 1, 5]))
        else:
            # mezcla: letras (quiz) y palabras falsas (modo palabra)
            texto = random.choice(LETRAS + PALABRAS_FALSAS)
            enviar_respuesta(args.server, args.session, viewer, texto)
        n += 1
        await asyncio.sleep(random.uniform(0.6, 1.6))
    print(f"MOCK terminado ({n} eventos)")


async def modo_real(args):
    try:
        from TikTokLive import TikTokLiveClient
        from TikTokLive.events import CommentEvent, GiftEvent
    except ImportError:
        print("Falta la librería TikTokLive. Instálala con:  py -3.12 -m pip install TikTokLive")
        return
    client = TikTokLiveClient(unique_id=args.user)

    @client.on(CommentEvent)
    async def on_comment(event: CommentEvent):
        enviar_respuesta(args.server, args.session, event.user.nickname or event.user.unique_id, event.comment)

    if args.gifts:
        @client.on(GiftEvent)
        async def on_gift(event: GiftEvent):
            if getattr(event, "streak_finished", True):
                enviar_gift(args.server, args.session, event.user.nickname or event.user.unique_id, max(1, event.gift.repeat_count or 1))

    print(f"Conectando al live de {args.user}… (Ctrl+C para salir)")
    ping_live(args.server, args.session, "tiktok")

    async def heartbeat():
        while True:
            await asyncio.sleep(15)
            enviar(args.server, "/api/game/bridge", {"session_id": args.session})

    asyncio.create_task(heartbeat())
    await client.connect()


def main():
    ap = argparse.ArgumentParser(description="Bridge TikTok → wordch4t")
    ap.add_argument("--session", required=True, help="session_id de la partida (copiado desde /host/)")
    ap.add_argument("--server", default="http://localhost:8787")
    ap.add_argument("--user", default="", help="@usuario de TikTok (modo real)")
    ap.add_argument("--mock", action="store_true", help="simula el chat (demo/pruebas)")
    ap.add_argument("--gifts", action="store_true", help="reenviar regalos (revelan sílaba)")
    ap.add_argument("--seconds", type=int, default=30, help="duración del modo mock")
    args = ap.parse_args()

    if not args.mock and not args.user:
        ap.error("modo real requiere --user @tucuenta (o usa --mock)")
    if args.mock:
        asyncio.run(modo_mock(args))
    else:
        asyncio.run(modo_real(args))


if __name__ == "__main__":
    main()
