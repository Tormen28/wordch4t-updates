#!/usr/bin/env python3
"""Bridge de TikTok → wordch4t.

Lee el chat de un live de TikTok y envía cada mensaje al servidor del juego
(POST /api/game/answer). Los regalos (gifts) revelan letras en el modo
palabra (POST /api/game/gift).

Conexión robusta (§2.9b de la propuesta v2.20):
  - backoff común con jitter (1, 2, 4, 8, 16, 30, 30… s), sin límite;
  - heartbeat cada 5 s a /api/live/heartbeat con estado y motivo, también
    cuando NO está conectado;
  - detecta el stream colgado (conectado y sin eventos) y reconecta;
  - live terminado / cuenta sin live → reintento cada 30 s;
  - 429, firma o «rate limit» → espera de 60 s que se duplica hasta 300 s;
  - event_id en cada respuesta/regalo + LRU de 2000 ids (nada duplicado);
  - cola de reenvío de 500 eventos si el servidor no responde.

Uso real:
    py -3.12 tiktok_bridge.py --session <id-del-live> --user @tucuenta

Modo mock (sin TikTok, para demos y pruebas):
    py -3.12 tiktok_bridge.py --session <id> --mock

Solo desarrollo (requiere WORDCH4T_DEV=1):
    py -3.12 tiktok_bridge.py --session <id> --source fake

Opcional:
    --server http://localhost:8787     (default)
    --gifts                            (reenvía regalos → revelar letra)
    --seconds 30                       (duración en mock / límite en fake)
    --stall-seconds 60                 (silencio que cuenta como colgado)
    --fake-live http://127.0.0.1:8797  (scripts/fake_live.py)
"""

import argparse
import asyncio
import hashlib
import json
import os
import random
import sys
import time
import urllib.error
import urllib.request
from collections import OrderedDict

# UTF-8 a la fuerza: sin consola, Windows usa cp1252 y los emojis reventaban
# el puente (UnicodeEncodeError). Nunca más.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

VIEWERS = ["ana", "beto", "carla", "dora", "elena", "frank", "gaby", "hugo"]
PALABRAS_FALSAS = ["perro", "gato", "casa", "piano", "fiesta", "teclado", "camino", "estrella", "botella", "ventana"]
LETRAS = ["a", "b", "c", "d"]

# ─── Política de reintento (§2.9b) ──────────────────────────────────────────
# Réplica exacta de server/internal/backoff: espera(n) = min(30, 1·2^(n−1)) con
# jitter en [0,8; 1,2], recortada a 30 s. El contador vuelve a 0 tras 60 s
# estable. RNG inyectable para que los tests sean deterministas.
BACKOFF_BASE = 1.0
BACKOFF_MAX = 30.0
BACKOFF_JITTER = 0.20
BACKOFF_RESET_AFTER = 60.0

# 429 / firma: espera mínima de 60 s, que se duplica hasta 300 s.
RATE_LIMIT_MIN = 60.0
RATE_LIMIT_MAX = 300.0

# Live terminado o cuenta sin live: reintento fijo cada 30 s, sin límite.
LIVE_ENDED_RETRY = 30.0

# Salud: heartbeat cada 5 s (siempre) y ping al juego mientras hay conexión.
HEARTBEAT_EVERY = 5.0
PING_EVERY = 15.0
STALL_SECONDS = 60.0

# Ni perdidos ni duplicados.
DEDUPE_MAX = 2000
QUEUE_MAX = 500
HTTP_TIMEOUT = 5

# Estados que viajan en el heartbeat.
STATE_CONNECTING = "connecting"
STATE_CONNECTED = "connected"
STATE_STALLED = "stalled"
STATE_RETRYING = "retrying"
STATE_LIVE_ENDED = "live_ended"
STATE_RATE_LIMITED = "rate_limited"
STATE_USER_NOT_FOUND = "user_not_found"

# Estados en los que se está esperando para volver a conectar.
_ESPERANDO = (STATE_RETRYING, STATE_STALLED, STATE_RATE_LIMITED, STATE_LIVE_ENDED)


def jitter_factor(rng=None) -> float:
    """Multiplicador de jitter: 0 → 0,8 · 0,5 → 1,0 · ~1 → 1,2 (sin RNG, 1,0)."""
    if rng is None:
        return 1.0
    try:
        f = float(rng.random())
    except Exception:
        f = 0.5
    if f < 0.0:
        f = 0.0
    if f > 1.0:
        f = 1.0
    return 1.0 - BACKOFF_JITTER + f * 2 * BACKOFF_JITTER


def backoff_delay(attempt: int, rng=None) -> float:
    """Espera del intento n (n ≥ 1): 1, 2, 4, 8, 16, 30, 30… s con jitter ±20 %."""
    n = max(1, int(attempt))
    base = min(BACKOFF_MAX, BACKOFF_BASE * (2 ** (n - 1)))
    ms = round(base * jitter_factor(rng) * 1000.0)
    espera = ms / 1000.0
    if espera > BACKOFF_MAX:
        espera = BACKOFF_MAX
    if espera < 0:
        espera = 0.0
    return espera


def rate_limit_delay(attempt: int, rng=None, retry_after=None) -> float:
    """Espera tras un 429/«rate limit»: 60 → 120 → 240 → 300 s o Retry-After.

    Nunca baja de 60 s (el mínimo de la política) ni pasa de 300 s salvo que
    el servidor mande explícitamente un Retry-After mayor.
    """
    if retry_after is not None:
        try:
            espera = float(retry_after)
        except (TypeError, ValueError):
            espera = RATE_LIMIT_MIN
        return max(RATE_LIMIT_MIN, espera)
    n = max(1, int(attempt))
    base = min(RATE_LIMIT_MAX, RATE_LIMIT_MIN * (2 ** (n - 1)))
    espera = base * jitter_factor(rng)
    if espera < RATE_LIMIT_MIN:
        espera = RATE_LIMIT_MIN
    if espera > RATE_LIMIT_MAX:
        espera = RATE_LIMIT_MAX
    return round(espera, 3)


class RateLimitLive(Exception):
    """TikTok (o la fuente falsa) está limitando conexiones: 429/firma."""

    def __init__(self, retry_after=None, msg="TikTok está limitando conexiones (429)"):
        super().__init__(msg)
        self.retry_after = retry_after


class LiveCaida(Exception):
    """La conexión con el live se cayó (websocket cerrado, 5xx, red)."""


class Dedupe:
    """LRU de ids de evento ya procesados (2000 por defecto)."""

    def __init__(self, maxlen: int = DEDUPE_MAX):
        self.maxlen = max(1, int(maxlen))
        self._vistos = OrderedDict()

    def registrar(self, event_id) -> bool:
        """Registra el id y dice si es NUEVO (True) o repetido (False)."""
        if not event_id:
            return True  # sin id no se puede deduplicar: nunca se pierde
        clave = str(event_id)
        if clave in self._vistos:
            self._vistos.move_to_end(clave)
            return False
        self._vistos[clave] = True
        while len(self._vistos) > self.maxlen:
            self._vistos.popitem(last=False)
        return True

    def __contains__(self, event_id) -> bool:
        return str(event_id) in self._vistos

    def __len__(self) -> int:
        return len(self._vistos)


class ColaReenvio:
    """Cola FIFO de eventos pendientes cuando el servidor no responde (500)."""

    def __init__(self, maxlen: int = QUEUE_MAX, log=None):
        self.maxlen = max(1, int(maxlen))
        self.items = []
        self.perdidos = 0
        self._log = log

    def push(self, server, path, payload) -> None:
        self.items.append((server, path, dict(payload)))
        # Si se llena, se tira lo MÁS VIEJO: lo nuevo es lo que el público
        # acaba de escribir y sigue teniendo valor.
        while len(self.items) > self.maxlen:
            self.items.pop(0)
            self.perdidos += 1

    def flush(self, enviar_fn=None) -> int:
        """Reenvía en orden. Se detiene en el primer fallo para no desordenar.

        Devuelve el status del último envío correcto (0 si no salió ninguno).
        """
        enviar_fn = enviar_fn or enviar
        ultimo = 0
        while self.items:
            server, path, payload = self.items[0]
            st, _body = enviar_fn(server, path, payload)
            if _retryable(st):
                break
            self.items.pop(0)
            ultimo = st
        return ultimo

    def __len__(self) -> int:
        return len(self.items)


def _retryable(status) -> bool:
    """¿Merece la pena reintentar este status del servidor?"""
    return status == 0 or status == 429 or status >= 500


def enviar(server: str, path: str, payload: dict):
    """POST JSON best-effort. Nunca lanza: (status, cuerpo)."""
    try:
        req = urllib.request.Request(
            server + path,
            data=json.dumps(payload).encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as r:
            raw = r.read()
            try:
                return r.status, json.loads(raw or b"{}")
            except (ValueError, TypeError):
                return 0, {"error": "respuesta no JSON"}
    except urllib.error.HTTPError as e:  # 4xx/5xx: interesa el código (429)
        try:
            raw = e.read() or b""
            cuerpo = json.loads(raw) if raw else {}
        except Exception:
            cuerpo = {"error": str(e)}
        if not isinstance(cuerpo, dict):
            cuerpo = {"error": str(e)}
        return int(e.code or 0), cuerpo
    except Exception as e:  # best-effort: el bridge nunca debe caerse
        return 0, {"error": str(e)}


BRIDGE_TOKEN = ""  # lo asigna main() con --bridge-token (autentica el bridge ante el juego)


def _payload(base: dict) -> dict:
    if BRIDGE_TOKEN:
        base["bridge_token"] = BRIDGE_TOKEN
    return base


# ─── Ids de evento (§2.9b «ni perdidos ni duplicados») ──────────────────────


def _leer(obj, *ruta, default=None):
    actual = obj
    for nombre in ruta:
        if actual is None:
            return default
        actual = getattr(actual, nombre, None)
    return default if actual is None else actual


def event_id_de(evento, *partes) -> str:
    """Id estable del evento: msg_id de TikTok o sha1(user|texto|create_time).

    En TikTokLive 7.x el id vive en ``event.common.msg_id`` (int). Se acepta
    también ``event.base_message.message_id`` por si cambia la taxonomía.
    """
    msg_id = _leer(evento, "common", "msg_id", default=0)
    if msg_id:
        return "m%s" % msg_id
    alterno = _leer(evento, "base_message", "message_id", default=None)
    if alterno:
        return "m%s" % alterno
    crudo = "|".join(str(p) for p in partes)
    return "h" + hashlib.sha1(crudo.encode("utf-8")).hexdigest()[:20]


def _emitir(server, path, payload, *, event_id=None, dedupe=None, cola=None, enviar_fn=None):
    """Envía un evento aplicando dedupe y cola de reenvío.

    Devuelve {"accion": sent|duplicate|queued, "status", "body"}.
    """
    dedupe = DEDUPE if dedupe is None else dedupe
    cola = COLA if cola is None else cola
    enviar_fn = enviar_fn or enviar
    if event_id is not None and str(event_id) != "":
        if not dedupe.registrar(event_id):
            return {"accion": "duplicate", "status": 0, "body": {"duplicate": True}}
        payload = dict(payload)
        payload["event_id"] = str(event_id)
    # Si quedan pendientes, primero se vacía la cola (para no desordenar) y
    # este evento entra detrás.
    if len(cola):
        cola.push(server, path, payload)
        ultimo = cola.flush(enviar_fn)
        if not len(cola):
            return {"accion": "sent", "status": ultimo, "body": {"ok": True}}
        return {"accion": "queued", "status": 0, "body": {"queued": len(cola)}}
    st, body = enviar_fn(server, path, payload)
    if _retryable(st):
        cola.push(server, path, payload)
        return {"accion": "queued", "status": st, "body": body}
    return {"accion": "sent", "status": st, "body": body}


DEDUPE = Dedupe(DEDUPE_MAX)
COLA = ColaReenvio(QUEUE_MAX)


def enviar_respuesta(server: str, sid: str, player: str, text: str, event_id=None,
                     *, dedupe=None, cola=None, enviar_fn=None):
    base = {"session_id": sid, "player": player, "text": text}
    res = _emitir(server, "/api/game/answer", _payload(base), event_id=event_id,
                  dedupe=dedupe, cola=cola, enviar_fn=enviar_fn)
    if res["accion"] == "duplicate":
        print(f"[respuesta] {player}: repetida (event_id {event_id}) — no se reenvía")
        return res
    body = res["body"] if isinstance(res["body"], dict) else {}
    marca = "✔" if body.get("correct") else "·"
    extra = " (en cola)" if res["accion"] == "queued" else ""
    print(f"[respuesta] {player}: {text!r} -> {res['status']} {marca} {body.get('points', '')}{extra}")
    return res


def enviar_gift(server: str, sid: str, player: str, count: int = 1, event_id=None,
                *, dedupe=None, cola=None, enviar_fn=None):
    base = {"session_id": sid, "player": player, "count": count}
    res = _emitir(server, "/api/game/gift", _payload(base), event_id=event_id,
                  dedupe=dedupe, cola=cola, enviar_fn=enviar_fn)
    if res["accion"] == "duplicate":
        return res
    print(f"[gift] {player} x{count} -> {res['status']} {res['body']}")
    return res


def ping_live(server: str, sid: str, etiqueta: str = "live"):
    """Avisa al juego que el live está conectado (la partida lo espera para arrancar)."""
    st, _ = enviar(server, "/api/game/bridge", _payload({"session_id": sid}))
    if st == 200:
        print(f"[{etiqueta}] Live conectado al juego ✔ (session {sid})")
    else:
        print(f"[{etiqueta}] aviso: no pude avisar al juego (status {st})")
    return st == 200


# ─── Estado de la conexión ──────────────────────────────────────────────────


def clasificar_error(exc):
    """Traduce una excepción a (estado, motivo). Mapea por SUBSTRING, nunca por
    clase exacta: la taxonomía de TikTokLive cambia entre versiones."""
    nombre = type(exc).__name__ if exc is not None else ""
    bajo = nombre.lower()
    msg = str(exc or "").lower()
    if "usernotfound" in bajo:
        return STATE_USER_NOT_FOUND, "user_not_found"
    if ("ratelimit" in bajo or "signapi" in bajo or "signature" in bajo
            or "429" in msg or "rate limit" in msg or "too many requests" in msg
            or "signature" in msg):
        return STATE_RATE_LIMITED, "rate_limited"
    if ("useroffline" in bajo or "usernotlive" in bajo or "liveend" in bajo
            or "invalidstatuscode" in bajo or "offline" in msg or "not live" in msg
            or "status code" in msg or "live has ended" in msg or "live end" in msg):
        return STATE_LIVE_ENDED, "live_ended"
    return STATE_RETRYING, (msg[:60] or nombre or "error")


class MaquinaLive:
    """Máquina de estados de la conexión: reloj y RNG inyectables."""

    def __init__(self, *, clock=time.time, rng=None, stall_seconds=STALL_SECONDS):
        self.clock = clock
        self.rng = rng if rng is not None else random.Random()
        self.stall_seconds = float(stall_seconds)
        self.started_at = float(self.clock())
        self.session_started_at = 0.0
        self.last_event_at = 0.0
        self.attempt = 0
        self.rate_attempt = 0
        self.state = STATE_RETRYING
        self.reason = "inicio"
        self.next_retry_at = self.started_at  # conecta ya

    def now(self) -> float:
        return float(self.clock())

    def conectando(self):
        self.state = STATE_CONNECTING
        self.reason = "conectando"

    def conectado(self, ts=None):
        ahora = self.now() if ts is None else float(ts)
        self.state = STATE_CONNECTED
        self.reason = "conectado"
        self.session_started_at = ahora
        self.next_retry_at = 0.0

    def evento(self, ts=None):
        self.last_event_at = self.now() if ts is None else float(ts)

    def actividad(self, ahora=None) -> float:
        """Instante desde el que se mide el silencio del stream.

        Es el último evento real; si aún no hubo ninguno, el inicio de la
        sesión. Ojo: 0.0 es un instante válido (relojes falsos), así que no
        se usa como «sin valor».
        """
        return max(float(self.last_event_at), float(self.session_started_at))

    def estable(self, ahora=None) -> bool:
        """60 s en verde → el contador de intentos vuelve a 0."""
        ahora = self.now() if ahora is None else ahora
        if self.state != STATE_CONNECTED or not self.session_started_at:
            return False
        if ahora - self.session_started_at >= BACKOFF_RESET_AFTER:
            self.attempt = 0
            self.rate_attempt = 0
            return True
        return False

    def stalled(self, ahora=None) -> bool:
        ahora = self.now() if ahora is None else ahora
        if self.state != STATE_CONNECTED:
            return False
        return (ahora - self.actividad(ahora)) >= self.stall_seconds

    def stall(self):
        """El stream está colgado: cerrar el cliente y reconectar con backoff."""
        ahora = self.now()
        self.attempt += 1
        self.state = STATE_STALLED
        self.reason = "stream_stalled"
        self.next_retry_at = ahora + backoff_delay(self.attempt, self.rng)

    def fin_live(self, motivo="live_ended"):
        self.attempt += 1
        self.state = STATE_LIVE_ENDED
        self.reason = motivo
        self.next_retry_at = self.now() + LIVE_ENDED_RETRY

    def fallo(self, exc=None, *, retry_after=None):
        estado, motivo = clasificar_error(exc)
        ahora = self.now()
        self.state = estado
        self.reason = motivo
        if estado == STATE_USER_NOT_FOUND:
            self.next_retry_at = 0.0
            return estado
        self.attempt += 1
        if estado == STATE_RATE_LIMITED:
            if retry_after is None:
                retry_after = getattr(exc, "retry_after", None)
            self.rate_attempt += 1
            self.next_retry_at = ahora + rate_limit_delay(self.rate_attempt, self.rng, retry_after)
        elif estado == STATE_LIVE_ENDED:
            self.next_retry_at = ahora + LIVE_ENDED_RETRY
        else:
            self.next_retry_at = ahora + backoff_delay(self.attempt, self.rng)
        return estado

    def espera(self, ahora=None) -> float:
        ahora = self.now() if ahora is None else ahora
        return max(0.0, self.next_retry_at - ahora)

    def tick(self, ahora=None):
        """Devuelve la acción: connect | stall | stop | None (esperar)."""
        ahora = self.now() if ahora is None else ahora
        if self.state == STATE_USER_NOT_FOUND:
            return "stop"
        if self.state == STATE_CONNECTED:
            self.estable(ahora)
            if self.stalled(ahora):
                return "stall"
            return None
        if self.state in _ESPERANDO:
            return "connect" if ahora >= self.next_retry_at else None
        return None

    def heartbeat(self, ahora=None) -> dict:
        ahora = self.now() if ahora is None else ahora
        return {
            "state": self.state,
            "attempt": self.attempt,
            "reason": self.reason,
            "last_event_at": round(self.last_event_at, 3),
            "next_retry_in": round(self.espera(ahora), 3) if self.state in _ESPERANDO else 0,
            "stall_seconds": self.stall_seconds,
        }


class Latido:
    """Heartbeat cada 5 s a /api/live/heartbeat (siempre, conectado o no).

    Mientras hay conexión también refresca el ping al juego (POST
    /api/game/bridge), que es el que hoy pinta el 🟢 del panel.
    """

    def __init__(self, server, sid, *, maquina, every=HEARTBEAT_EVERY, clock=time.time,
                 enviar_fn=None, source="tiktok", ping_every=PING_EVERY):
        self.server = server
        self.sid = sid
        self.maquina = maquina
        self.every = float(every)
        self.ping_every = float(ping_every)
        self.clock = clock
        self.enviar_fn = enviar_fn or enviar
        self.source = source
        self.last_sent = None
        self.last_ping = None
        self.last_ok = None
        self.last_status = 0
        self.last_event_id = 0
        self.enviados = 0
        self._aviso = ""  # último aviso impreso (para no repetir líneas)

    def payload(self, ahora=None) -> dict:
        ahora = self.maquina.now() if ahora is None else ahora
        base = {"session_id": self.sid, "source": self.source}
        base.update(self.maquina.heartbeat(ahora))
        return _payload(base)

    def maybe_send(self, ahora=None, forzar=False) -> bool:
        ahora = self.maquina.now() if ahora is None else ahora
        if not forzar and self.last_sent is not None and (ahora - self.last_sent) < self.every:
            return False
        self.last_sent = ahora
        self.enviados += 1
        st, body = self.enviar_fn(self.server, "/api/live/heartbeat", self.payload(ahora))
        self.last_status = st
        if st == 200:
            self.last_ok = ahora
            if isinstance(body, dict):
                try:
                    cursor = int(body.get("last_event_id") or 0)
                except (TypeError, ValueError):
                    cursor = 0
                if cursor > self.last_event_id:
                    self.last_event_id = cursor
        else:
            # Un solo aviso por racha: el registro del panel son 6 líneas.
            aviso = "heartbeat sin respuesta del servidor (status %s)" % st
            if aviso != self._aviso:
                self._aviso = aviso
                print(f"[latido] {aviso}")
        if self.maquina.state == STATE_CONNECTED:
            if self.last_ping is None or (ahora - self.last_ping) >= self.ping_every:
                self.last_ping = ahora
                st_ping, _ = self.enviar_fn(self.server, "/api/game/bridge",
                                            _payload({"session_id": self.sid}))
                if st_ping != 200:
                    self.last_ping = None  # reintenta en el próximo latido
        return True


class Despachador:
    """Convierte un evento normalizado en la petición al juego."""

    def __init__(self, server, sid, *, maquina=None, dedupe=None, cola=None, enviar_fn=None):
        self.server = server
        self.sid = sid
        self.maquina = maquina
        self.dedupe = DEDUPE if dedupe is None else dedupe
        self.cola = COLA if cola is None else cola
        self.enviar_fn = enviar_fn

    def evento(self, ev: dict) -> str:
        if not isinstance(ev, dict):
            return "ignored"
        if self.maquina is not None:
            # CUALQUIER evento cuenta como actividad del stream (like, join…).
            self.maquina.evento(ev.get("ts"))
        kind = ev.get("kind") or "other"
        eid = ev.get("event_id")
        if kind == "comment":
            res = enviar_respuesta(self.server, self.sid, ev.get("player") or "?",
                                   ev.get("text") or "", event_id=eid,
                                   dedupe=self.dedupe, cola=self.cola,
                                   enviar_fn=self.enviar_fn)
            return res["accion"]
        if kind == "gift":
            res = enviar_gift(self.server, self.sid, ev.get("player") or "?",
                              int(ev.get("count") or 1), event_id=eid,
                              dedupe=self.dedupe, cola=self.cola,
                              enviar_fn=self.enviar_fn)
            return res["accion"]
        if kind == "live_end":
            if self.maquina is not None:
                self.maquina.fin_live()
            return "live_end"
        return "ignored"


def normalizar_comment(event) -> dict:
    return {
        "kind": "comment",
        "player": _leer(event, "user", "nickname", default=None) or _leer(event, "user", "unique_id", default="?"),
        "text": _leer(event, "content", default="") or "",
        "event_id": event_id_de(event, _leer(event, "user", "id", default=""),
                                _leer(event, "content", default=""),
                                _leer(event, "common", "create_time", default="")),
    }


def normalizar_gift(event) -> dict:
    count = int(_leer(event, "repeat_count", default=0) or _leer(event, "gift", "repeat_count", default=1) or 1)
    return {
        "kind": "gift",
        "player": _leer(event, "user", "nickname", default=None) or _leer(event, "user", "unique_id", default="?"),
        "count": max(1, count),
        "event_id": event_id_de(event, _leer(event, "user", "id", default=""),
                                _leer(event, "gift_id", default=""),
                                _leer(event, "common", "create_time", default="")),
    }


# ─── Sesiones: TikTok real y fuente falsa (solo dev) ────────────────────────


def _gift_listo(event) -> bool:
    """¿Toca enviar este regalo? En un combo solo al cerrar (repeatEnd).

    Un regalo suelto (repeat_count ≤ 1) se manda siempre: en TikTokLive 7.x
    `repeat_end` puede llegar en 0 y no queremos perder el regalo.
    """
    if getattr(event, "repeat_end", 0):
        return True
    try:
        return int(getattr(event, "repeat_count", 1) or 1) <= 1
    except (TypeError, ValueError):
        return True


class SesionTikTok:
    """Una conexión al live real. `correr()` bloquea mientras hay conexión."""

    def __init__(self, *, user, server, sid, despachador, maquina, latido=None,
                 dormir=asyncio.sleep):
        self.user = user
        self.server = server
        self.sid = sid
        self.despachador = despachador
        self.maquina = maquina
        self.latido = latido
        self.dormir = dormir

    async def correr(self) -> dict:
        from TikTokLive import TikTokLiveClient
        from TikTokLive import events as ev

        cliente = TikTokLiveClient(unique_id=self.user)
        motivo = "cerrada"
        error = None

        @cliente.on(ev.CommentEvent)
        async def on_comment(event):
            self.despachador.evento(normalizar_comment(event))

        @cliente.on(ev.GiftEvent)
        async def on_gift(event):
            if _gift_listo(event):
                self.despachador.evento(normalizar_gift(event))
            else:  # el combo sigue: es actividad, pero no se manda todavía
                self.maquina.evento()

        @cliente.on(ev.LiveEndEvent)
        async def on_end(event):
            nonlocal motivo
            motivo = "live_end"
            self.maquina.fin_live()
            try:
                await cliente.disconnect()
            except Exception:
                pass

        @cliente.on(ev.ConnectEvent)
        async def on_connect(event):
            self.maquina.conectado()
            ping_live(self.server, self.sid, "tiktok")

        @cliente.on(ev.DisconnectEvent)
        async def on_disconnect(event):
            print("[tiktok] la conexión se cayó")

        # Cualquier otra señal del live cuenta como actividad (anti-colgado).
        for tipo in (getattr(ev, "LikeEvent", None), getattr(ev, "JoinEvent", None),
                     getattr(ev, "FollowEvent", None), getattr(ev, "RoomUserSeqEvent", None)):
            if tipo is None:
                continue
            try:
                cliente.on(tipo, self._solo_actividad)
            except Exception:
                pass

        async def vigilar():
            nonlocal motivo
            while True:
                await asyncio.sleep(1.0)
                if self.latido is not None:
                    self.latido.maybe_send()
                if self.maquina.stalled(self.maquina.now()):
                    self.maquina.stall()
                    motivo = "stalled"
                    try:
                        await cliente.disconnect()
                    except Exception:
                        pass
                    return

        tarea = asyncio.create_task(vigilar())
        print(f"[tiktok] conectando al live de @{self.user}…")
        try:
            await cliente.connect()
        except Exception as e:
            error = e
            motivo = "error"
        finally:
            tarea.cancel()
            try:
                await cliente.disconnect()
            except Exception:
                pass
        return {"motivo": motivo, "error": error}

    async def _solo_actividad(self, event):
        self.maquina.evento()


class SesionFalsa:
    """Lee scripts/fake_live.py por HTTP (SOLO DESARROLLO)."""

    def __init__(self, *, url, despachador, maquina, latido=None, dormir=asyncio.sleep,
                 intervalo=0.4, clock=time.time, limite=None, http_get=None):
        self.url = url.rstrip("/")
        self.despachador = despachador
        self.maquina = maquina
        self.latido = latido
        self.dormir = dormir
        self.intervalo = float(intervalo)
        self.clock = clock
        self.limite = limite
        self.cursor = 0
        self.http_get = http_get or _http_get_json

    def _pedir(self, after: int) -> dict:
        return self.http_get(f"{self.url}/events?after={int(after)}")

    async def correr(self) -> dict:
        motivo, error = "cerrada", None
        inicio = self.clock()
        if self.latido is not None:
            # Primer latido ANTES de la primera lectura: así el bridge sabe
            # hasta qué evento tiene el servidor (`last_event_id`) y un
            # relanzamiento no vuelve a leer lo que el motor ya atendió
            # (§2.9b: nada perdido, nada duplicado).
            self.latido.maybe_send(forzar=True)
        while True:
            if self.limite is not None and (self.clock() - inicio) >= self.limite:
                return {"motivo": "fin_prueba", "error": None}
            after = max(self.cursor, self.latido.last_event_id if self.latido else 0)
            try:
                datos = await asyncio.to_thread(self._pedir, after)
            except RateLimitLive as e:
                error, motivo = e, "error"
                break
            except Exception as e:
                error, motivo = e, "error"
                break
            if self.maquina.state != STATE_CONNECTED:
                # Primera lectura buena: la fuente falsa está «en vivo».
                self.maquina.conectado()
            for ev in datos.get("events") or []:
                try:
                    self.cursor = max(self.cursor, int(ev.get("id") or 0))
                except (TypeError, ValueError):
                    pass
                self.despachador.evento(ev)
                if ev.get("kind") == "live_end":
                    self.maquina.fin_live()
                    return {"motivo": "live_end", "error": None}
            if self.latido is not None:
                self.latido.maybe_send()
            if self.maquina.stalled(self.maquina.now()):
                self.maquina.stall()
                return {"motivo": "stalled", "error": None}
            if datos.get("ended"):
                self.maquina.fin_live()
                return {"motivo": "live_end", "error": None}
            await self.dormir(self.intervalo)
        return {"motivo": motivo, "error": error}


def _http_get_json(url: str, timeout: float = 3.0) -> dict:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        if e.code == 429:
            retry = e.headers.get("Retry-After") if e.headers else None
            try:
                retry = int(retry) if retry is not None else None
            except (TypeError, ValueError):
                retry = None
            raise RateLimitLive(retry_after=retry)
        raise LiveCaida(f"la fuente falsa respondió {e.code}")
    except Exception as e:
        raise LiveCaida(str(e))


# ─── Bucle de conexión ──────────────────────────────────────────────────────


def mensaje_estado(maquina, exc=None, intentos=0) -> str:
    """Texto amable para el registro del panel (lo ve el streamer)."""
    if maquina.state == STATE_RATE_LIMITED:
        return ("[tiktok] ⚠️ TikTok está limitando conexiones; reintento en "
                f"{maquina.espera():.0f} s")
    if maquina.state == STATE_LIVE_ENDED:
        return ("[tiktok] ⚠️ El LIVE terminó o la cuenta no está en vivo. "
                "Reintento cada 30 s (vuelve a transmitir y conecta solo)…")
    if maquina.state == STATE_STALLED:
        return ("[tiktok] ⚠️ El stream dejó de dar señales; reconectando en "
                f"{maquina.espera():.0f} s…")
    if maquina.state == STATE_USER_NOT_FOUND:
        return "[tiktok] ⚠️ No encontré esa cuenta de TikTok. Revisa el usuario."
    return ("[tiktok] reconectando (intento %d) en %.0f s…"
            % (intentos, maquina.espera()))


async def bucle_live(*, maquina, abrir_sesion, latido=None, dormir=asyncio.sleep,
                     max_sesiones=None, log=print, tick=1.0, deadline=None):
    """Conecta, mantiene y reconecta sola mientras el streamer quiera.

    `abrir_sesion()` devuelve un objeto con `correr()` (async) que devuelve
    {"motivo": cerrada|stalled|live_end|error|fin_prueba, "error": exc|None}.
    `deadline` (instante del reloj de la máquina) corta una prueba: las esperas
    largas, como los 60 s de un 429, no impiden terminar cuando toca.
    Reloj, RNG, sesión y `dormir` son inyectables para los tests.
    """
    sesiones = 0
    ultimo_aviso = None
    while True:
        ahora = maquina.now()
        if deadline is not None and ahora >= deadline:
            log("[tiktok] fin de la prueba (--seconds)")
            return "fin_prueba"
        if latido is not None:
            latido.maybe_send(ahora)
        accion = maquina.tick(ahora)
        if accion == "stop":
            if not (ultimo_aviso and ultimo_aviso[0] == maquina.state):
                log(mensaje_estado(maquina))
            return "user_not_found"
        if accion == "stall":
            maquina.stall()
            continue
        if accion != "connect":
            espera = tick
            if maquina.state in _ESPERANDO:
                espera = min(max(maquina.espera(ahora), 0.05), tick)
            await dormir(max(0.05, espera))
            continue

        maquina.conectando()
        sesiones += 1
        resultado = await abrir_sesion().correr()
        motivo = (resultado or {}).get("motivo") or "error"
        error = (resultado or {}).get("error")
        if motivo == "fin_prueba":
            log("[tiktok] fin de la prueba (--seconds)")
            return "fin_prueba"
        if motivo == "live_end" or maquina.state == STATE_LIVE_ENDED:
            if maquina.state != STATE_LIVE_ENDED:
                maquina.fin_live()
        elif motivo == "stalled" or maquina.state == STATE_STALLED:
            if maquina.state != STATE_STALLED:
                maquina.stall()
        else:
            if motivo == "cerrada" and error is None and maquina.state == STATE_CONNECTED:
                error = LiveCaida("conexion_cerrada")
            maquina.fallo(error)
        aviso = (maquina.state, round(maquina.espera()))
        if aviso != ultimo_aviso:
            ultimo_aviso = aviso
            log(mensaje_estado(maquina, error, maquina.attempt))
        if latido is not None:
            latido.maybe_send(maquina.now(), forzar=True)
        if max_sesiones is not None and sesiones >= max_sesiones:
            return "limite"


# ─── Modos de ejecución ─────────────────────────────────────────────────────


async def modo_mock(args):
    print(f"Modo MOCK: simulando chat durante {args.seconds}s (session {args.session})")
    ping_live(args.server, args.session, "mock")
    t0 = time.time()
    last_ping = time.time()
    n = 0
    while time.time() - t0 < args.seconds:
        if time.time() - last_ping > 10:
            ping_live(args.server, args.session, "mock")
            last_ping = time.time()
        viewer = random.choice(VIEWERS)
        if args.gifts and n % 5 == 4:
            enviar_gift(args.server, args.session, viewer, random.choice([1, 1, 5]))
        else:
            # mezcla: letras (quiz) y palabras falsas (modo palabra)
            texto = random.choice(LETRAS + PALABRAS_FALSAS)
            enviar_respuesta(args.server, args.session, viewer, texto)
        n += 1
        await asyncio.sleep(random.uniform(0.6, 1.6))
    print(f"MOCK terminado ({n} eventos)")


def _preparar(args, *, source, stall_seconds):
    maquina = MaquinaLive(stall_seconds=stall_seconds)
    latido = Latido(args.server, args.session, maquina=maquina, source=source)
    despachador = Despachador(args.server, args.session, maquina=maquina)
    return maquina, latido, despachador


async def modo_real(args):
    try:
        import TikTokLive  # noqa: F401
    except ImportError:
        print("Falta la librería TikTokLive. Instálala con:  py -3.12 -m pip install TikTokLive")
        return

    unique = args.user.strip().lstrip("@")  # el @ rompe la conexión: se quita
    maquina, latido, despachador = _preparar(args, source="tiktok", stall_seconds=args.stall_seconds)

    def abrir():
        return SesionTikTok(user=unique, server=args.server, sid=args.session,
                            despachador=despachador, maquina=maquina, latido=latido)

    await bucle_live(maquina=maquina, abrir_sesion=abrir, latido=latido)


async def modo_fake(args):
    """Fuente falsa (solo desarrollo): scripts/fake_live.py."""
    if os.environ.get("WORDCH4T_DEV", "") != "1":
        print("--source fake solo existe con WORDCH4T_DEV=1 (solo desarrollo)")
        return
    segundos = 0 if args.seconds is None else args.seconds
    maquina, latido, despachador = _preparar(args, source="fake", stall_seconds=args.stall_seconds)
    print(f"Modo FAKE: leyendo {args.fake_live} (session {args.session})")
    limite = (time.time() + segundos) if segundos > 0 else None

    def abrir():
        return SesionFalsa(url=args.fake_live, despachador=despachador, maquina=maquina,
                           latido=latido, limite=(segundos if segundos > 0 else None))

    await bucle_live(maquina=maquina, abrir_sesion=abrir, latido=latido, deadline=limite)


def main():
    ap = argparse.ArgumentParser(description="Bridge TikTok → wordch4t")
    ap.add_argument("--session", required=True, help="id del live (copiado desde el panel)")
    ap.add_argument("--server", default="http://localhost:8787")
    ap.add_argument("--user", default="", help="@usuario de TikTok (modo real)")
    ap.add_argument("--mock", action="store_true", help="simula el chat (demo/pruebas)")
    ap.add_argument("--gifts", action="store_true", help="reenviar regalos (revelan letra)")
    ap.add_argument("--seconds", type=int, default=None,
                    help="duración del mock (30 por defecto) o límite del fake (0 = sin límite)")
    ap.add_argument("--bridge-token", default="", help="token del live (lo pasa la app)")
    ap.add_argument("--stall-seconds", type=float, default=STALL_SECONDS,
                    help="silencio que cuenta como stream colgado (60 s)")
    ap.add_argument("--source", choices=("tiktok", "fake"), default="tiktok")
    ap.add_argument("--fake-live", default="http://127.0.0.1:8797")
    args = ap.parse_args()

    global BRIDGE_TOKEN
    BRIDGE_TOKEN = args.bridge_token or ""

    if args.mock and args.source == "fake":
        ap.error("--mock y --source fake son excluyentes")
    if args.source == "fake" and os.environ.get("WORDCH4T_DEV", "") != "1":
        print("--source fake solo existe con WORDCH4T_DEV=1 (solo desarrollo)")
        sys.exit(2)
    if not args.mock and args.source != "fake" and not args.user:
        ap.error("modo real requiere --user @tucuenta (o usa --mock)")
    if args.source == "fake" and args.seconds is None:
        args.seconds = 0

    if args.mock:
        if args.seconds is None:
            args.seconds = 30
        asyncio.run(modo_mock(args))
    elif args.source == "fake":
        asyncio.run(modo_fake(args))
    else:
        asyncio.run(modo_real(args))


if __name__ == "__main__":
    main()
