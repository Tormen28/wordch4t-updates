#!/usr/bin/env python3
"""Bridge de TikTok → wordch4t.

Lee el chat de un live de TikTok y envía cada mensaje al servidor del juego
(POST /api/game/answer). Los regalos (gifts) revelan sílabas en el modo
palabra (POST /api/game/gift).

Uso real:
    py -3.12 tiktok_bridge.py --session <session_id> --user @tucuenta

Modo mock (sin TikTok, para demos y pruebas):
    py -3.12 tiktok_bridge.py --session <session_id> --mock

Opcional:
    --server http://localhost:8787     (default)
    --gifts                            (reenvía regalos → revelar sílaba)
    --seconds 30                       (duración en modo mock)
"""

import argparse
import asyncio
import json
import random
import sys
import time
import urllib.request

# UTF-8 a la fuerza: sin consola, Windows usa cp1252 y los emojis reventaban
# el puente (UnicodeEncodeError). Nunca más.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

VIEWERS = ["ana", "beto", "carla", "dora", "elena", "frank", "gaby", "hugo"]
PALABRAS_FALSAS = ["perro", "gato", "casa", "piano", "fiesta", "teclado", "camino", "estrella", "botella", "ventana"]
LETRAS = ["a", "b", "c", "d"]


def enviar(server: str, path: str, payload: dict):
    try:
        req = urllib.request.Request(
            server + path,
            data=json.dumps(payload).encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read() or b"{}")
    except Exception as e:  # best-effort: el bridge nunca debe caerse
        return 0, {"error": str(e)}


BRIDGE_TOKEN = ""  # lo asigna main() con --bridge-token (autentica el bridge ante el juego)


def _payload(base: dict) -> dict:
    if BRIDGE_TOKEN:
        base["bridge_token"] = BRIDGE_TOKEN
    return base


def enviar_respuesta(server: str, sid: str, player: str, text: str):
    st, body = enviar(server, "/api/game/answer", _payload({"session_id": sid, "player": player, "text": text}))
    marca = "✔" if body.get("correct") else "·"
    print(f"[respuesta] {player}: {text!r} -> {st} {marca} {body.get('points', '')}")


def enviar_gift(server: str, sid: str, player: str, count: int = 1):
    st, body = enviar(server, "/api/game/gift", _payload({"session_id": sid, "player": player, "count": count}))
    print(f"[gift] {player} x{count} -> {st} {body}")


def ping_live(server: str, sid: str, etiqueta: str = "live"):
    """Avisa al juego que el live está conectado (la partida lo espera para arrancar)."""
    st, _ = enviar(server, "/api/game/bridge", _payload({"session_id": sid}))
    if st == 200:
        print(f"[{etiqueta}] Live conectado al juego ✔ (session {sid})")
    else:
        print(f"[{etiqueta}] aviso: no pude avisar al juego (status {st})")
    return st == 200


async def modo_mock(args):
    print(f"Modo MOCK: simulando chat durante {args.seconds}s (session {args.session})")
    ping_live(args.server, args.session, "mock")
    t0 = time.time()
    last_ping = time.time()
    n = 0
    while time.time() - t0 < args.seconds:
        if time.time() - last_ping > 10:
            ping_live(args.server, args.session, "mock")
            last_ping = time.time()
        viewer = random.choice(VIEWERS)
        if args.gifts and n % 5 == 4:
            enviar_gift(args.server, args.session, viewer, random.choice([1, 1, 5]))
        else:
            # mezcla: letras (quiz) y palabras falsas (modo palabra)
            texto = random.choice(LETRAS + PALABRAS_FALSAS)
            enviar_respuesta(args.server, args.session, viewer, texto)
        n += 1
        await asyncio.sleep(random.uniform(0.6, 1.6))
    print(f"MOCK terminado ({n} eventos)")


async def modo_real(args):
    try:
        from TikTokLive import TikTokLiveClient
        from TikTokLive.events import CommentEvent, GiftEvent, ConnectEvent, DisconnectEvent
    except ImportError:
        print("Falta la librería TikTokLive. Instálala con:  py -3.12 -m pip install TikTokLive")
        return

    unique = args.user.strip().lstrip("@")  # el @ rompe la conexión: se quita
    intento = 0
    estado = {"ok": False}  # estado real de la conexión (manejado por eventos TikTok)
    while True:
        intento += 1
        try:
            client = TikTokLiveClient(unique_id=unique)

            @client.on(CommentEvent)
            async def on_comment(event: CommentEvent):
                enviar_respuesta(args.server, args.session, event.user.nickname or event.user.unique_id, event.comment)

            if args.gifts:
                @client.on(GiftEvent)
                async def on_gift(event: GiftEvent):
                    if getattr(event, "streak_finished", True):
                        enviar_gift(args.server, args.session, event.user.nickname or event.user.unique_id, max(1, event.gift.repeat_count or 1))

            @client.on(ConnectEvent)
            async def on_connect(event: ConnectEvent):
                # AVISO AL JUEGO solo cuando la conexión real está lista
                estado["ok"] = True
                ping_live(args.server, args.session, "tiktok")

            @client.on(DisconnectEvent)
            async def on_disconnect(event: DisconnectEvent):
                # la conexión cayó: el juego lo notará y el bucle reconecta solo
                estado["ok"] = False
                print("[tiktok] conexión caída — reconectando solo…")

            print(f"[tiktok] conectando al live de @{unique} (intento {intento})…")

            async def heartbeat():
                # mantiene vivo el aviso SOLO mientras la conexión real siga activa
                while True:
                    await asyncio.sleep(15)
                    if estado["ok"]:
                        enviar(args.server, "/api/game/bridge", _payload({"session_id": args.session}))

            hb = asyncio.create_task(heartbeat())
            try:
                await client.connect()
            finally:
                estado["ok"] = False
                hb.cancel()

            print("[tiktok] la conexión terminó; reintentando en 10 s…")
            await asyncio.sleep(10)
        except Exception as e:
            nombre = type(e).__name__
            msg = str(e)
            if "UserNotFound" in nombre:
                print(f"[tiktok] ⚠️ No encontré el usuario @{unique}. Revisa el nombre (sin @) y usa Conectar otra vez.")
                return
            if ("UserNotLive" in nombre or "UserOffline" in nombre or "InvalidStatusCode" in nombre
                    or "not live" in msg.lower() or "offline" in msg.lower() or "status code" in msg.lower()):
                print(f"[tiktok] ⚠️ @{unique} no está EN VIVO en este momento. Abre tu LIVE en TikTok y se conectará solo (reintento cada 15 s)…")
            else:
                print(f"[tiktok] ⚠️ No pude conectar ({nombre}). Reintentando en 15 s…")
            await asyncio.sleep(15)


def main():
    ap = argparse.ArgumentParser(description="Bridge TikTok → wordch4t")
    ap.add_argument("--session", required=True, help="session_id de la partida (copiado desde /host/)")
    ap.add_argument("--server", default="http://localhost:8787")
    ap.add_argument("--user", default="", help="@usuario de TikTok (modo real)")
    ap.add_argument("--mock", action="store_true", help="simula el chat (demo/pruebas)")
    ap.add_argument("--gifts", action="store_true", help="reenviar regalos (revelan sílaba)")
    ap.add_argument("--seconds", type=int, default=30, help="duración del modo mock")
    ap.add_argument("--bridge-token", default="", help="token de la sesión (lo pasa la app; autentica el bridge)")
    args = ap.parse_args()

    global BRIDGE_TOKEN
    BRIDGE_TOKEN = args.bridge_token or ""

    if not args.mock and not args.user:
        ap.error("modo real requiere --user @tucuenta (o usa --mock)")
    if args.mock:
        asyncio.run(modo_mock(args))
    else:
        asyncio.run(modo_real(args))


if __name__ == "__main__":
    main()
